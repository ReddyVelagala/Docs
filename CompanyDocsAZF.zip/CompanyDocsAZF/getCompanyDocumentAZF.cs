using System;
using System.IO;
using System.Net;
using System.Web;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using CompanyDocument.Services;

namespace GeoAccountsAZF
{
    public static class getCompanyDocumentAZF
    {
        [FunctionName("getCompanyDocumentAZF")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("called getCompanyDocumentAZF.\n");

            string RegId = req.Query["RegId"];
            CompanyDocumentApi compObj = new CompanyDocumentApi();
            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            dynamic data = JsonConvert.DeserializeObject(requestBody);
            RegId = RegId ?? data?.RegId;

            string responseMessage = string.IsNullOrEmpty(RegId)
                ? "Please provide company registeration Id \"RegId\" for doanloding the doc.\n"
                : $"Donalodng company docs for registeration Id = {RegId}.\n";
            if(string.IsNullOrEmpty(RegId)){
                 return new OkObjectResult(responseMessage);
            }  
            bool res = compObj.DownlaodCompanyDoc(RegId);
            
             
            return new OkObjectResult(responseMessage);
        }
    }

    public static class getCompanyDocUrlAZF
    {
        [FunctionName("getCompanyDocUrlAZF")]
        public static async Task<HttpResponseMessage> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("called getCompanyDocUrlAZF.\n");

            string RegId = req.Query["RegId"];

            CompanyDocumentApi compObj = new CompanyDocumentApi();
            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            dynamic data = JsonConvert.DeserializeObject(requestBody);
            RegId = RegId ?? data?.RegId;
            string html = "";
            
            string responseMessage = string.IsNullOrEmpty(RegId)
                ? "Please provide company registeration Id \"RegId\" for doanloding the doc.\n"
                : $"Donalodng company docs for registeration Id = {RegId}.\n";
            var result = new HttpResponseMessage();
            if(string.IsNullOrEmpty(RegId)){
                  html = $"<html>{responseMessage}</html>";
                  result = new HttpResponseMessage(HttpStatusCode.OK);
                  result.Content = new ByteArrayContent(System.Text.Encoding.UTF8.GetBytes(html));
                  //result.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment")
                 //      { FileName = "file.html" };
                  //result.Content.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");
                  result.Content.Headers.ContentType = new MediaTypeHeaderValue("text/html");
                  return result;
            }  
            System.Net.Http.HttpContent response   = await compObj.getCompanyDocUrl(RegId);
            //responseMessage = responseMessage+$"The URL for document download is = {result}";
             

            if(response != null) { 
                result = new HttpResponseMessage(HttpStatusCode.OK);
                result.Content = new ByteArrayContent(await response.ReadAsByteArrayAsync());
                //result.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment")
                //         { FileName = "file.pdf" };
                result.Content.Headers.ContentType = new MediaTypeHeaderValue("application/pdf");
            }else{
                result = new HttpResponseMessage(HttpStatusCode.OK);
                result.Content = new StringContent("Error in fetching company doc");
                //result.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment")
                //         { FileName = "file.pdf" };
                result.Content.Headers.ContentType = new MediaTypeHeaderValue("text/html");    
            }
            return result;

        }
    }
    public static class convertToOCRAZF
    {
        [FunctionName("convertToOCRAZF")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("called getCompanyDocumentAZF.\n");

            string RegId = req.Query["RegId"];
            CompanyDocumentApi compObj = new CompanyDocumentApi();
            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            dynamic data = JsonConvert.DeserializeObject(requestBody);
            RegId = RegId ?? data?.RegId;

            string responseMessage = string.IsNullOrEmpty(RegId)
                ? "Please provide company registeration Id \"RegId\" for doanloding the doc.\n"
                : $"Donalodng company docs for registeration Id = {RegId}.\n";
            if(string.IsNullOrEmpty(RegId)){
                 return new OkObjectResult(responseMessage);
            }  
            bool res = await compObj.ConvertOCR(RegId);
            
             
            return new OkObjectResult(responseMessage);
        }
    }
}
